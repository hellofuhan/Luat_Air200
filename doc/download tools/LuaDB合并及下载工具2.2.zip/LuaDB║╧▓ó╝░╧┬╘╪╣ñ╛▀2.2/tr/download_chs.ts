<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nb">
<context>
    <name>BomNum</name>
    <message>
        <location filename="../UI/BomNum.ui" line="14"/>
        <source>Select Bom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="20"/>
        <source>BOM Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="30"/>
        <source>BOM_00130</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="59"/>
        <source>OK</source>
        <translation type="unfinished">确定</translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="66"/>
        <source>Cancel</source>
        <translation type="unfinished">取消</translation>
    </message>
</context>
<context>
    <name>LoginDlg</name>
    <message>
        <location filename="../UI/Login.ui" line="33"/>
        <source>Login</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="../UI/Login.ui" line="53"/>
        <source>Please input the password:</source>
        <translation>请输入密码:</translation>
    </message>
    <message>
        <location filename="../UI/Login.ui" line="75"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../UI/Login.ui" line="82"/>
        <source>CANCEL</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../UI/mainwnd.ui" line="23"/>
        <source>MainWindow</source>
        <translation>主窗口</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="40"/>
        <source>Produce Type</source>
        <translation type="unfinished">选择类型</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="46"/>
        <source>Basic+LuaDB</source>
        <translation type="unfinished">平台Lod+LuaDB</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="53"/>
        <source>Only LuaDB</source>
        <translation type="unfinished">仅LuaDB</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="60"/>
        <source>LuaDB_Bin</source>
        <translation type="unfinished">LuaDB.bin</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="76"/>
        <source>Group Lua Files</source>
        <translation type="unfinished">LuaDB脚本文件表格</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="83"/>
        <location filename="../UI/mainwnd.ui" line="103"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="88"/>
        <location filename="../UI/mainwnd.ui" line="108"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="93"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="98"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="122"/>
        <location filename="../UI/mainwnd.ui" line="397"/>
        <source>Button</source>
        <translation type="unfinished">按钮</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="128"/>
        <source>Append</source>
        <translation type="unfinished">添加</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="135"/>
        <source>Delete</source>
        <translation type="unfinished">删除</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="142"/>
        <source>Select ALL</source>
        <translation type="unfinished">全选</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="174"/>
        <source>Select foundation platform</source>
        <translation type="unfinished">选择平台文件</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="180"/>
        <source>Basic File</source>
        <translation type="unfinished">平台文件</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="190"/>
        <location filename="../UI/mainwnd.ui" line="387"/>
        <source>B&amp;rowse&gt;&gt;</source>
        <translation type="unfinished">浏览</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="216"/>
        <source>Download</source>
        <translation type="unfinished">下载</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="280"/>
        <location filename="../UI/mainwnd.ui" line="479"/>
        <source>Start all</source>
        <translation>全部开始</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="287"/>
        <location filename="../UI/mainwnd.ui" line="488"/>
        <source>Stop all</source>
        <translation>全部停止</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="313"/>
        <source>Initialize</source>
        <translation type="unfinished">初始化</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="353"/>
        <source>Combine</source>
        <translation type="unfinished">合并</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="371"/>
        <source>Combined to generate files</source>
        <translation type="unfinished">合并生成文件</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="377"/>
        <source>Export File</source>
        <translation type="unfinished">选择导出文件</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="403"/>
        <source>Production </source>
        <translation type="unfinished">合并进度</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="417"/>
        <source>Merge</source>
        <translation type="unfinished">合并</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="497"/>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="506"/>
        <source>User manual</source>
        <translation>用户手册</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="294"/>
        <location filename="../UI/mainwnd.ui" line="515"/>
        <source>Setup</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="524"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="539"/>
        <source>StatusBar</source>
        <translation>状态条</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="554"/>
        <source>ToolBar</source>
        <translation>工具条</translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="563"/>
        <source>User management</source>
        <translation>用户管理</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="178"/>
        <source>Loading the lod file...</source>
        <translation>正在加载lod 文件...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="178"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="244"/>
        <source>&amp;Operations</source>
        <translation>(&amp;O)操作</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="254"/>
        <source>&amp;View</source>
        <translation>(&amp;V)视图</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>&amp;Help</source>
        <translation>(&amp;H)帮助</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="291"/>
        <source>Port number</source>
        <translation>端口号</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="294"/>
        <source>Serial port</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="297"/>
        <source>Progress (%)</source>
        <translation>进度(%)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="300"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="303"/>
        <source>Times</source>
        <translation>用时</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <source>Port %1</source>
        <translation>端口%1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>Closed</source>
        <translation>已关闭</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="151"/>
        <location filename="../mainwindow.cpp" line="429"/>
        <location filename="../mainwindow.cpp" line="870"/>
        <location filename="../mainwindow.cpp" line="879"/>
        <location filename="../mainwindow.cpp" line="2077"/>
        <location filename="../mainwindow.cpp" line="2191"/>
        <location filename="../mainwindow.cpp" line="3024"/>
        <location filename="../mainwindow.cpp" line="3031"/>
        <location filename="../mainwindow.cpp" line="3582"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>8851 custome download tool Vx.x</source>
        <translation type="obsolete">8851系列_客户下载工具_V1.7(8851A 8851CL 8851ML)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="129"/>
        <location filename="../mainwindow.cpp" line="3967"/>
        <source>8851 product download tool Vx.x</source>
        <translation type="unfinished">8851系列_产线下载工具_V1.9(8851A 8851CL 8851ML)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="133"/>
        <source>RDA download tool v8.00.09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>download.cfg did not exist,we will create a new file!</source>
        <translation>download.cfg文件不存在,我们将创建一个新文件!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <location filename="../mainwindow.cpp" line="899"/>
        <location filename="../mainwindow.cpp" line="1360"/>
        <location filename="../mainwindow.cpp" line="1367"/>
        <location filename="../mainwindow.cpp" line="2090"/>
        <location filename="../mainwindow.cpp" line="2204"/>
        <location filename="../mainwindow.cpp" line="2261"/>
        <location filename="../mainwindow.cpp" line="2275"/>
        <location filename="../mainwindow.cpp" line="2297"/>
        <location filename="../mainwindow.cpp" line="2311"/>
        <location filename="../mainwindow.cpp" line="2434"/>
        <location filename="../mainwindow.cpp" line="2470"/>
        <location filename="../mainwindow.cpp" line="2497"/>
        <location filename="../mainwindow.cpp" line="2505"/>
        <location filename="../mainwindow.cpp" line="2522"/>
        <location filename="../mainwindow.cpp" line="2530"/>
        <location filename="../mainwindow.cpp" line="2555"/>
        <location filename="../mainwindow.cpp" line="2569"/>
        <location filename="../mainwindow.cpp" line="2664"/>
        <location filename="../mainwindow.cpp" line="2672"/>
        <location filename="../mainwindow.cpp" line="2690"/>
        <location filename="../mainwindow.cpp" line="2698"/>
        <location filename="../mainwindow.cpp" line="2723"/>
        <location filename="../mainwindow.cpp" line="2737"/>
        <location filename="../mainwindow.cpp" line="2841"/>
        <location filename="../mainwindow.cpp" line="2910"/>
        <location filename="../mainwindow.cpp" line="3074"/>
        <location filename="../mainwindow.cpp" line="3088"/>
        <location filename="../mainwindow.cpp" line="3103"/>
        <location filename="../mainwindow.cpp" line="3143"/>
        <location filename="../mainwindow.cpp" line="3156"/>
        <location filename="../mainwindow.cpp" line="3446"/>
        <location filename="../mainwindow.cpp" line="3483"/>
        <location filename="../mainwindow.cpp" line="3561"/>
        <location filename="../mainwindow.cpp" line="3570"/>
        <location filename="../mainwindow.cpp" line="3611"/>
        <location filename="../mainwindow.cpp" line="3619"/>
        <location filename="../mainwindow.cpp" line="3627"/>
        <location filename="../mainwindow.cpp" line="3635"/>
        <location filename="../mainwindow.cpp" line="3643"/>
        <location filename="../mainwindow.cpp" line="3651"/>
        <location filename="../mainwindow.cpp" line="3861"/>
        <location filename="../mainwindow.cpp" line="5011"/>
        <location filename="../mainwindow.cpp" line="5018"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <location filename="../mainwindow.cpp" line="2090"/>
        <location filename="../mainwindow.cpp" line="2204"/>
        <source>Error configure file!</source>
        <translation>配置文件错误!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="899"/>
        <source>Create configure error!</source>
        <translation>创建配置文件错误!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1360"/>
        <location filename="../mainwindow.cpp" line="1367"/>
        <location filename="../mainwindow.cpp" line="5018"/>
        <source>Write Configure file failed!</source>
        <translation>写配置文件错误!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2077"/>
        <source>flashlist.cfg did not exist!</source>
        <translation>flashlist.cfg文件不存在!</translation>
    </message>
    <message>
        <source>platformlist.cfg did not exist!</source>
        <translation type="obsolete">platformlist.cfg文件不存在!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2261"/>
        <source>Import MBSN from excel file failed!</source>
        <translation>从excel文件导入MBSN失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2275"/>
        <source>Custom MBSN failed!</source>
        <translation>定制MBSN失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2297"/>
        <source>Import PSN from excel file failed!</source>
        <translation>从excel文件到入PSN失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2311"/>
        <source>Custom PSN failed!</source>
        <translation>定制PSN失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2434"/>
        <source>Can&apos;t update the History MBSN file!</source>
        <translation>不能更新历史MBSN列表!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2470"/>
        <source>Can&apos;t update the History phone SN file!</source>
        <translation>不能更新历史PSN列表!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2497"/>
        <location filename="../mainwindow.cpp" line="2664"/>
        <source>The source file does not exist!</source>
        <translation>源文件不存在!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2505"/>
        <location filename="../mainwindow.cpp" line="2672"/>
        <source>Create a excel object failed!</source>
        <translation>创建excel对象失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2522"/>
        <location filename="../mainwindow.cpp" line="2690"/>
        <source>Not find the string sheet in the excel file!</source>
        <translation>在excel文件里没有找到表单!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2530"/>
        <location filename="../mainwindow.cpp" line="2698"/>
        <source>Create a backup excel object failed!</source>
        <translation>创建备份excel对象失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2555"/>
        <location filename="../mainwindow.cpp" line="2723"/>
        <source>Empty file or the format of file is error!</source>
        <translation>空文件或者文件格式错误!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2569"/>
        <location filename="../mainwindow.cpp" line="2737"/>
        <source>Read excel file error!</source>
        <translation>读excel文件错误!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2841"/>
        <source>The custom part of MBSN must be digits or letters!</source>
        <translation>MBSN可定制部分必须是数字或者字母!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2910"/>
        <source>The custom part of PSN must be digits or letters!</source>
        <translation>PSN可定制部分必须是数字或者字母!</translation>
    </message>
    <message>
        <source>About Coolsand download tool</source>
        <translation type="obsolete">关于互芯下载工具</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="151"/>
        <location filename="../mainwindow.cpp" line="3582"/>
        <source>Failed to get flash info from lod file, we will use the parameters in configure!</source>
        <translation>不能从LOD文件获取Flash信息，请手动设置这些参数!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="306"/>
        <source>Light</source>
        <translation type="unfinished">灯</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2191"/>
        <source>lcdlist.cfg did not exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3000"/>
        <source>About RDA download tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3001"/>
        <source>RDA download tool v8.00.09
Copyright reserved 2012-12-03</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3071"/>
        <source>Checksum of the lod file failed, Continue to download?</source>
        <translation type="unfinished">LOD文件校验和出错,是否坚持继续下载?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3102"/>
        <source>[%1] was not exist,please select the correct flash programmer file!</source>
        <translation>[%1]不存在，请选择正确的Flash类型!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3128"/>
        <location filename="../mainwindow.cpp" line="3431"/>
        <location filename="../mainwindow.cpp" line="3468"/>
        <source>[%1] was not exist,please select the correct file!</source>
        <translation>[%1]不存在，请选择正确的文件!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3132"/>
        <location filename="../mainwindow.cpp" line="3435"/>
        <location filename="../mainwindow.cpp" line="3472"/>
        <source>The address in cfp file must be equal to the calib address of current flash!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3136"/>
        <location filename="../mainwindow.cpp" line="3439"/>
        <location filename="../mainwindow.cpp" line="3476"/>
        <source>Can not find the calib section!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3140"/>
        <location filename="../mainwindow.cpp" line="3443"/>
        <location filename="../mainwindow.cpp" line="3480"/>
        <source>Open [%1] failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3155"/>
        <source>You must select at least one content to update!</source>
        <translation>您必须选择至少一个更新区域!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3560"/>
        <source>The program is already running</source>
        <translation type="unfinished">请停止再操作</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3569"/>
        <source>Failed to Initiate the download file</source>
        <translation type="unfinished">下载模式初始化失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3650"/>
        <source>You had not loaded a lod file successfully!</source>
        <translation>没有成功加载Lod文件!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4114"/>
        <source>Statu</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4117"/>
        <source>Press</source>
        <translation type="unfinished">压缩</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4120"/>
        <source>LuaFile</source>
        <translation type="unfinished">Lua脚本</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4136"/>
        <source>No.%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5340"/>
        <location filename="../mainwindow.cpp" line="5348"/>
        <location filename="../mainwindow.cpp" line="5356"/>
        <location filename="../mainwindow.cpp" line="5406"/>
        <location filename="../mainwindow.cpp" line="5921"/>
        <location filename="../mainwindow.cpp" line="5928"/>
        <location filename="../mainwindow.cpp" line="6158"/>
        <location filename="../mainwindow.cpp" line="6328"/>
        <location filename="../mainwindow.cpp" line="6343"/>
        <location filename="../mainwindow.cpp" line="6374"/>
        <source>warning</source>
        <translation type="unfinished">警告</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5467"/>
        <location filename="../mainwindow.cpp" line="5473"/>
        <location filename="../mainwindow.cpp" line="5479"/>
        <location filename="../mainwindow.cpp" line="5486"/>
        <location filename="../mainwindow.cpp" line="5491"/>
        <source>critical</source>
        <translation type="unfinished">错误</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5486"/>
        <source>Failed to get scripts and user first address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[%1] not exist,Please add</source>
        <translation type="obsolete">[%1]不存在于脚本表格中，请手动添加</translation>
    </message>
    <message>
        <source>[%1] has not been used, Continue to download?</source>
        <translation type="obsolete">[%1]未被使用，是否继续？</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6328"/>
        <source>LuaFile renaming failure!</source>
        <translation type="unfinished">脚本文件重命名失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6343"/>
        <source>Copy the Lua file failed!</source>
        <translation type="unfinished">复制脚本文件失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5467"/>
        <source>Lod files illegal lack # $SCRIPT</source>
        <translation type="unfinished">平台文件非法，缺少#$SCRIPT</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5473"/>
        <source>Please select at least one lua files</source>
        <translation type="unfinished">请至少添加一个lua脚本文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5479"/>
        <source>main.lua not exist</source>
        <translation type="unfinished">main.lua不存在</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5340"/>
        <source>error:Platform file can&apos;t Read </source>
        <translation type="unfinished">读平台文件失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="127"/>
        <source>LuaDB tools and downloads_V1.8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5348"/>
        <source>error:Export file can&apos;t Write</source>
        <translation type="unfinished">写导出文件失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5356"/>
        <source>error: Temp_Download.lod can&apos;t Write</source>
        <translation type="unfinished">临时下载文件不能写</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5491"/>
        <source> lua files data is greater than #$SCRIPT_DATA_SIZE</source>
        <translation type="unfinished">平台Lod文件脚本空间不足！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6158"/>
        <source>Lua_libraryini file can&apos;t Read </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6228"/>
        <source>%1 script file are missing!</source>
        <translation type="unfinished">%1个脚本文件缺失，请添加</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6229"/>
        <source>Do you want to view the list of missing?</source>
        <translation type="unfinished">请点击下面显示细节按钮查看Lua缺失列表</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6270"/>
        <source>%1 script file are unnecessary!</source>
        <translation type="unfinished">%1个Lua脚本文件未被使用</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6271"/>
        <source>Whether to remove redundancy, continue?</source>
        <translation type="unfinished">是否去掉冗余Lua文件？</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6374"/>
        <source>Script file compression failure</source>
        <translation type="unfinished">Lua脚本压缩失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5406"/>
        <source>ZipFile error:can&apos;t open  error</source>
        <translation type="unfinished">读脚本压缩文件失败</translation>
    </message>
    <message>
        <source>Platform lod file has no #$SCRIPT_DATA_BASE parameter</source>
        <translation type="obsolete">平台lod文件没有#$SCRIPT_DATA_BASE参数</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5886"/>
        <source>Marge the Lod files</source>
        <translation type="unfinished">合并成功</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5890"/>
        <source>Combine the lod files failure</source>
        <translation type="unfinished">合并失败</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5921"/>
        <source>error: Update failed to download the CFG file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5928"/>
        <source>error:LuaDB.bin are not allowed to download </source>
        <translation type="unfinished">LuaDB.bin不支持下载</translation>
    </message>
    <message>
        <source>Coolsand download tool</source>
        <translation type="obsolete">互芯下载工具</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="870"/>
        <location filename="../mainwindow.cpp" line="879"/>
        <source>The length of the PSN was not equal to the length of the custum string!</source>
        <translation>PSN的长度和定制字符串长度不一致!</translation>
    </message>
    <message>
        <source>Coolsand download tool v7.00.01
Copyright reserved 2012-01-12</source>
        <translation type="obsolete">互芯下载工具版本 7.00.01
版权所有 2012-01-12</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3087"/>
        <location filename="../mainwindow.cpp" line="3626"/>
        <location filename="../mainwindow.cpp" line="3860"/>
        <source>Checksum of the lod file failed!</source>
        <translation>Lod文件校验失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3610"/>
        <source>Load ramrun file failed!</source>
        <translation>加载ramrun文件失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3618"/>
        <source>Load Lod file failed!</source>
        <translation>加载lod文件失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3634"/>
        <source>Load CFP file failed!</source>
        <translation>加载CFP文件失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3642"/>
        <source>Load erase file failed!</source>
        <translation>加载擦除文件失败!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="250"/>
        <source>&amp;Manage</source>
        <translation>(&amp;M)管理</translation>
    </message>
</context>
<context>
    <name>PasswordDlg</name>
    <message>
        <location filename="../UI/Password.ui" line="13"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="53"/>
        <source>New password:</source>
        <translation>新密码:</translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="110"/>
        <source>Confirm:</source>
        <translation>确认:</translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="137"/>
        <source>Old password:</source>
        <translation>旧密码:</translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="169"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="176"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>QDownloadThread</name>
    <message>
        <location filename="../DownloadThread.cpp" line="114"/>
        <location filename="../DownloadThread.cpp" line="159"/>
        <location filename="../DownloadThread.cpp" line="906"/>
        <source>Closed</source>
        <translation>已关闭</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="180"/>
        <source>Init uart port failed!</source>
        <translation>初始化UART口失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="193"/>
        <source>Open uart port failed!</source>
        <translation>打开UART口失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="230"/>
        <source>Connecting Database...</source>
        <translation type="unfinished">正在连接数据库...</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="237"/>
        <source>Connect Database Failed!</source>
        <translation type="unfinished">连接数据库失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="249"/>
        <source>Idle</source>
        <translation>空闲</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="320"/>
        <source>You had select a false flash type!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="335"/>
        <source>Downloading...</source>
        <translation>下载...</translation>
    </message>
    <message>
        <source>Read UART cfg error!</source>
        <translation type="obsolete">读UART参数错误!</translation>
    </message>
    <message>
        <source>Write UART cfg error!</source>
        <translation type="obsolete">写UART参数错误!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="357"/>
        <source>Read Chip ID error!</source>
        <translation>读芯片ID错误!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="367"/>
        <location filename="../DownloadThread.cpp" line="385"/>
        <location filename="../DownloadThread.cpp" line="406"/>
        <source>Base address was not matched!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="377"/>
        <location filename="../DownloadThread.cpp" line="416"/>
        <source>%1 file was not existed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="429"/>
        <source>Load ramrun failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="436"/>
        <source>Get UID failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="471"/>
        <location filename="../DownloadThread.cpp" line="674"/>
        <source>Read audio data from target failed!</source>
        <translation>读板端音频数据失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="493"/>
        <location filename="../DownloadThread.cpp" line="696"/>
        <source>Read RF data from target failed!</source>
        <translation>读板端RF数据失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="568"/>
        <source>Check the former worksite flag failed!</source>
        <translation>检查前一工位标志失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="613"/>
        <source>Get SN/IMEI Failed,please connect the DBM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="619"/>
        <source>IMEI number is invalid, please connect the DBM and check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="624"/>
        <source>BOM number of SN is invalid, please connect the DBM and check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="747"/>
        <source>Verify flash failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="752"/>
        <source>Calib RF CRC failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="757"/>
        <source>Magic number error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="762"/>
        <source>Fast programmer file failed!</source>
        <translation>下载文件失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="776"/>
        <source>Update Imei/SN status Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="806"/>
        <source>Finished!</source>
        <translation>完成!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="297"/>
        <source>Lock the XCPU failed!</source>
        <translation>锁XCPU失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="274"/>
        <location filename="../DownloadThread.cpp" line="818"/>
        <source>Uart port was not found!</source>
        <translation>UART端口不存在!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="342"/>
        <source>Enter host mode failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="515"/>
        <source>Read other data from target failed!</source>
        <translation>读其他信息失败!</translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="718"/>
        <source>Read Other data from target failed!</source>
        <translation>读其他时局失败!</translation>
    </message>
</context>
<context>
    <name>QLoginDlg</name>
    <message>
        <location filename="../Login.cpp" line="18"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../Login.cpp" line="18"/>
        <source>The password is not correct!</source>
        <translation>密码不正确!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="29"/>
        <location filename="../mainwindow.cpp" line="111"/>
        <location filename="../mainwindow.cpp" line="3358"/>
        <location filename="../mainwindow.cpp" line="3369"/>
        <location filename="../mainwindow.cpp" line="3396"/>
        <location filename="../mainwindow.cpp" line="3407"/>
        <location filename="../mainwindow.cpp" line="3512"/>
        <location filename="../mainwindow.cpp" line="3523"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="29"/>
        <source>You have already run an application.</source>
        <translation>这个应用程序已经在运行了.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="111"/>
        <source>The flash you had selected was not existed in our flash list</source>
        <translation>您选择的Flash在我们的flash列表中不存在</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3358"/>
        <location filename="../mainwindow.cpp" line="3396"/>
        <location filename="../mainwindow.cpp" line="3512"/>
        <source>The lod file has overwrite the factorysetting sector!</source>
        <translation>Lod文件覆盖到了出厂设置区!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3369"/>
        <location filename="../mainwindow.cpp" line="3407"/>
        <location filename="../mainwindow.cpp" line="3523"/>
        <source>The lod file has overwrite the calibration sector!</source>
        <translation>Lod文件覆盖了校准扇区!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6448"/>
        <source>[%1] can&apos;t open for search!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3184"/>
        <location filename="../mainwindow.cpp" line="3207"/>
        <location filename="../mainwindow.cpp" line="3234"/>
        <location filename="../mainwindow.cpp" line="3246"/>
        <location filename="../mainwindow.cpp" line="3273"/>
        <location filename="../mainwindow.cpp" line="3285"/>
        <location filename="../mainwindow.cpp" line="3313"/>
        <location filename="../mainwindow.cpp" line="3325"/>
        <location filename="../mainwindow.cpp" line="3346"/>
        <location filename="../mainwindow.cpp" line="3384"/>
        <location filename="../mainwindow.cpp" line="3500"/>
        <source>[%1] was not exist,please select the correct file!</source>
        <translation>[%1]不存在，请选择正确的文件!</translation>
    </message>
</context>
<context>
    <name>QPasswordDlg</name>
    <message>
        <location filename="../Password.cpp" line="18"/>
        <location filename="../Password.cpp" line="28"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../Password.cpp" line="18"/>
        <source>The password is not correct!</source>
        <translation>密码不正确!</translation>
    </message>
    <message>
        <location filename="../Password.cpp" line="28"/>
        <source>The new password is not confirmed correctly!</source>
        <translation>密码确认不正确!</translation>
    </message>
</context>
<context>
    <name>QSetupDialog</name>
    <message>
        <location filename="../SetupDialog.cpp" line="854"/>
        <location filename="../SetupDialog.cpp" line="1485"/>
        <location filename="../SetupDialog.cpp" line="1494"/>
        <location filename="../SetupDialog.cpp" line="1693"/>
        <location filename="../SetupDialog.cpp" line="1708"/>
        <location filename="../SetupDialog.cpp" line="1717"/>
        <location filename="../SetupDialog.cpp" line="1732"/>
        <location filename="../SetupDialog.cpp" line="1742"/>
        <location filename="../SetupDialog.cpp" line="1752"/>
        <location filename="../SetupDialog.cpp" line="1775"/>
        <location filename="../SetupDialog.cpp" line="1785"/>
        <location filename="../SetupDialog.cpp" line="1800"/>
        <location filename="../SetupDialog.cpp" line="1809"/>
        <location filename="../SetupDialog.cpp" line="1827"/>
        <location filename="../SetupDialog.cpp" line="1837"/>
        <location filename="../SetupDialog.cpp" line="1848"/>
        <location filename="../SetupDialog.cpp" line="1858"/>
        <location filename="../SetupDialog.cpp" line="1883"/>
        <location filename="../SetupDialog.cpp" line="1892"/>
        <location filename="../SetupDialog.cpp" line="1907"/>
        <location filename="../SetupDialog.cpp" line="1916"/>
        <location filename="../SetupDialog.cpp" line="1924"/>
        <location filename="../SetupDialog.cpp" line="1943"/>
        <location filename="../SetupDialog.cpp" line="1953"/>
        <location filename="../SetupDialog.cpp" line="1964"/>
        <location filename="../SetupDialog.cpp" line="1974"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>You must select the content of calibration sector you want to erase!</source>
        <translation type="obsolete">您必须选择希望擦除的校准扇区的内容!</translation>
    </message>
    <message>
        <source>Select LOD File</source>
        <translation type="obsolete">选择LOD文件</translation>
    </message>
    <message>
        <source>LOD files (*.lod *.cfp)</source>
        <translation type="obsolete">LOD文件(*lod *.cfp)</translation>
    </message>
    <message>
        <source>Select accessional File</source>
        <translation type="obsolete">选择附加文件</translation>
    </message>
    <message>
        <source>Accessional files (*.lod *.cfp)</source>
        <translation type="obsolete">附加文件(*.lod *.cfp)</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1115"/>
        <location filename="../SetupDialog.cpp" line="1122"/>
        <source>The 1st worksite</source>
        <translation>第一个工位</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1116"/>
        <location filename="../SetupDialog.cpp" line="1123"/>
        <source>The 2nd worksite</source>
        <translation>第二个工位</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1117"/>
        <location filename="../SetupDialog.cpp" line="1124"/>
        <source>The 3rd worksite</source>
        <translation>第三个工位</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1118"/>
        <location filename="../SetupDialog.cpp" line="1125"/>
        <source>The 4th worksite</source>
        <translation>第四个工位</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1119"/>
        <location filename="../SetupDialog.cpp" line="1126"/>
        <source>The 5th worksite</source>
        <translation>第五个工位</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1120"/>
        <location filename="../SetupDialog.cpp" line="1127"/>
        <source>The 6th worksite</source>
        <translation>第六个工位</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1129"/>
        <source>Normal mode</source>
        <translation>正常模式</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1130"/>
        <source>Auto dial mode</source>
        <translation>自动拨号模式</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1131"/>
        <source>Auto reply mode</source>
        <translation>自动应答模式</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1132"/>
        <source>Auto test mode</source>
        <translation>自动测试模式</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1234"/>
        <source>Port number</source>
        <translation>端口号</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1237"/>
        <source>Serial port</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1240"/>
        <source>Baud rate(bps)</source>
        <translation>波特率(bps)</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1250"/>
        <source>Port 1</source>
        <translation>端口1</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1267"/>
        <source>Port 2</source>
        <translation>端口2</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1284"/>
        <source>Port 3</source>
        <translation>端口3</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1301"/>
        <source>Port 4</source>
        <translation>端口4</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1318"/>
        <source>Port 5</source>
        <translation>端口5</translation>
    </message>
    <message>
        <source>Port 6</source>
        <translation type="obsolete">端口6</translation>
    </message>
    <message>
        <source>Port 7</source>
        <translation type="obsolete">端口7</translation>
    </message>
    <message>
        <source>Port 8</source>
        <translation type="obsolete">端口8</translation>
    </message>
    <message>
        <source>Port 9</source>
        <translation type="obsolete">端口9</translation>
    </message>
    <message>
        <source>Port 10</source>
        <translation type="obsolete">端口10</translation>
    </message>
    <message>
        <source>Port 11</source>
        <translation type="obsolete">端口11</translation>
    </message>
    <message>
        <source>Port 12</source>
        <translation type="obsolete">端口12</translation>
    </message>
    <message>
        <source>Port 13</source>
        <translation type="obsolete">端口13</translation>
    </message>
    <message>
        <source>Port 14</source>
        <translation type="obsolete">端口14</translation>
    </message>
    <message>
        <source>Port 15</source>
        <translation type="obsolete">端口15</translation>
    </message>
    <message>
        <source>Port 16</source>
        <translation type="obsolete">端口16</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1494"/>
        <source>The length of Init or Mask code of PSN error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1799"/>
        <source>MBSN&apos;s initial number must be digits or letters and consist of %1 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1906"/>
        <source>PSN&apos;s initial number must be digits or letters and consist of %1 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Excel File</source>
        <translation type="obsolete">选择excel文件</translation>
    </message>
    <message>
        <source>Excel files (*.xls)</source>
        <translation type="obsolete">Excel文件(*.xls)</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1693"/>
        <source>Serial Port can not repeat.</source>
        <translation>串口不能被重复选择.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1708"/>
        <source>Program file can not be empty.</source>
        <translation>程序文件不能为空.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1717"/>
        <source>Accessional file can not be empty.</source>
        <translation>附加文件不能为空.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1732"/>
        <source>Check last worksite flag can not be empty.</source>
        <translation>要检查的上一个工位不能为空.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1742"/>
        <source>Set current worksite flag can not be empty.</source>
        <translation>要设置的当前工位不能为空.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1752"/>
        <source>Set check flag can not be empty.</source>
        <translation>设置标志不能为空.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1775"/>
        <source>MBSN&apos;s max limited number must be digits.</source>
        <translation>MBSN最大的限制数量必须是数字.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1785"/>
        <source>MBSN&apos;s max limited number can&apos;t exceed 100000</source>
        <translation>MBSN最大限制数不能超过100000</translation>
    </message>
    <message>
        <source>MBSN&apos;s initial number must be digits or letters and consist of 16 characters.</source>
        <translation type="obsolete">MBSN的初始号码必须是数字或者字母并且由16个字符组成.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1809"/>
        <location filename="../SetupDialog.cpp" line="1827"/>
        <source>MBSN&apos;s mask is invalid.</source>
        <translation>SN掩码不可用.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1837"/>
        <location filename="../SetupDialog.cpp" line="1858"/>
        <source>MBSN&apos;s initial number and Mask should match</source>
        <translation>MBSN的初始号码和掩码必须匹配</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1848"/>
        <source>MBSN&apos;s custom-made characters must be digitals</source>
        <translation>MBSN的定制字符部分必须是数字</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1883"/>
        <source>PSN&apos;s max limited number must be digits.</source>
        <translation>PSN的最大限制数必须是数字.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1892"/>
        <source>PSN&apos;s max limited number can&apos;t exceed 100000</source>
        <translation>PSN的最大限制数不能超过100000</translation>
    </message>
    <message>
        <source>PSN&apos;s initial number must be digits or letters and consist of 20 characters.</source>
        <translation type="obsolete">PSN的初始号码必须是数字或字母，并且必须由20个字符组成.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1916"/>
        <location filename="../SetupDialog.cpp" line="1924"/>
        <location filename="../SetupDialog.cpp" line="1943"/>
        <source>PSN&apos;s mask is invalid.</source>
        <translation>PSN的掩码不可用.</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1953"/>
        <location filename="../SetupDialog.cpp" line="1974"/>
        <source>PSN&apos;s initial number and Mask should match</source>
        <translation>PSN的初始号码和掩码必须匹配</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1964"/>
        <source>PSN&apos;s custom-made characters must be digitals</source>
        <translation>PSN的自定制部分必须是数字</translation>
    </message>
    <message>
        <source>Select ramrun</source>
        <translation type="obsolete">选择Ramrun文件</translation>
    </message>
    <message>
        <source>LOD files (*.lod)</source>
        <translation type="obsolete">LOD文件(*.lod)</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="520"/>
        <location filename="../SetupDialog.cpp" line="526"/>
        <location filename="../SetupDialog.cpp" line="534"/>
        <location filename="../SetupDialog.cpp" line="540"/>
        <location filename="../SetupDialog.cpp" line="549"/>
        <location filename="../SetupDialog.cpp" line="559"/>
        <location filename="../SetupDialog.cpp" line="574"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="520"/>
        <source>Lod file must not be empty!</source>
        <translation>LOD文件不能为空文件!</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="526"/>
        <location filename="../SetupDialog.cpp" line="540"/>
        <source>[%1] is not exist!</source>
        <translation>[%1]不存在!</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="534"/>
        <source>Update file must not be empty!</source>
        <translation>更新文件不能为空!</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="574"/>
        <source>You must select a LCD ID!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="854"/>
        <source>Failed to get flash info from lod file,you must set the flash parameters manual!</source>
        <translation>从Lod文件读取Flash信息失败，请手动设置Flash类型!</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="549"/>
        <location filename="../SetupDialog.cpp" line="559"/>
        <source>You must select at least on content to be updated!</source>
        <translation>您必须选择至少一个需要更新的区域!</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1485"/>
        <source>The length of Init or Mask code of MBSN error!</source>
        <translation>定制MBSN的初始码和掩码长度错误!</translation>
    </message>
    <message>
        <source>The length of Init or Mask code of PSNerror!</source>
        <translation type="obsolete">定制PSN的初始码和掩码长度错误!</translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <location filename="../UI/setupdlg.ui" line="14"/>
        <source>Setup</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="73"/>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="97"/>
        <source>Port setting</source>
        <translation>端口设置</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="163"/>
        <source>Download</source>
        <translation>下载</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="181"/>
        <source>Download files</source>
        <translation>下载文件</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="369"/>
        <source>Accessional file</source>
        <translation>附加文件</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="272"/>
        <location filename="../UI/setupdlg.ui" line="398"/>
        <location filename="../UI/setupdlg.ui" line="957"/>
        <location filename="../UI/setupdlg.ui" line="1119"/>
        <source>Browse&gt;&gt;</source>
        <translation>浏览&gt;&gt;</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="281"/>
        <location filename="../UI/setupdlg.ui" line="431"/>
        <source>Update calibration paramters</source>
        <translation>更新校准参数</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="293"/>
        <location filename="../UI/setupdlg.ui" line="443"/>
        <source>Audio data</source>
        <translation>音频数据</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="303"/>
        <location filename="../UI/setupdlg.ui" line="453"/>
        <source>RF data</source>
        <translation>RF数据</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="235"/>
        <source>Program file</source>
        <translation>程序文件</translation>
    </message>
    <message>
        <source>ChipSet</source>
        <translation type="obsolete">芯片组</translation>
    </message>
    <message>
        <source>Chipset</source>
        <translation type="obsolete">芯片组</translation>
    </message>
    <message>
        <source>Chip</source>
        <translation type="obsolete">芯片</translation>
    </message>
    <message>
        <source>Platform</source>
        <translation type="obsolete">平台</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="487"/>
        <source>LCD Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="509"/>
        <source>LCD Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="571"/>
        <location filename="../UI/setupdlg.ui" line="597"/>
        <source>Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="617"/>
        <source>Flash Type</source>
        <translation>Flash类型</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="667"/>
        <source>Erase setting</source>
        <translation>擦除设置</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="679"/>
        <source>Erase user date sector</source>
        <translation>擦除用户数据扇区</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="692"/>
        <source>Erase factory setting sector</source>
        <translation>擦除出厂设置扇区</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="702"/>
        <source>Erase calibration sector</source>
        <translation>擦除校准扇区</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="709"/>
        <source>Erase full flash</source>
        <translation>擦除整个Flash</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="735"/>
        <source>Set flag</source>
        <translation>设标志位</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="777"/>
        <source>Flag options</source>
        <translation>标志选项</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="803"/>
        <source>Check last worksite flag</source>
        <translation>检查前一个工位标志</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="816"/>
        <source>Set current worksite flag</source>
        <translation>设置当前工位标志</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="829"/>
        <source>Set power on mode flag</source>
        <translation>设置开机模式</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="906"/>
        <source>Write SN</source>
        <translation>写SN</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="921"/>
        <source>Motherboard SN</source>
        <translation>主板SN</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="947"/>
        <location filename="../UI/setupdlg.ui" line="1102"/>
        <source>From data file</source>
        <translation>来自数据文件</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="974"/>
        <location filename="../UI/setupdlg.ui" line="1136"/>
        <source>Custom number</source>
        <translation>定制号码</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1020"/>
        <location filename="../UI/setupdlg.ui" line="1188"/>
        <source>Initial number</source>
        <translation>初始号码</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1034"/>
        <location filename="../UI/setupdlg.ui" line="1205"/>
        <source>Mask</source>
        <translation>掩码</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1058"/>
        <location filename="../UI/setupdlg.ui" line="1232"/>
        <source>Max limited number</source>
        <translation>最大限制数量</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1076"/>
        <source>Phone SN</source>
        <translation>手机SN</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1248"/>
        <location filename="../UI/setupdlg.ui" line="1260"/>
        <location filename="../UI/setupdlg.ui" line="1285"/>
        <source>DataBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1275"/>
        <source>Data Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1299"/>
        <source>User Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1313"/>
        <source>Password</source>
        <translation type="unfinished">密码</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1348"/>
        <source>Sequence No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1358"/>
        <source>Prdt Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1374"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="47"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="54"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="323"/>
        <location filename="../UI/setupdlg.ui" line="473"/>
        <source>All</source>
        <translation>所有参数</translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="313"/>
        <location filename="../UI/setupdlg.ui" line="463"/>
        <source>GPADC</source>
        <translation>电池参数</translation>
    </message>
</context>
</TS>
