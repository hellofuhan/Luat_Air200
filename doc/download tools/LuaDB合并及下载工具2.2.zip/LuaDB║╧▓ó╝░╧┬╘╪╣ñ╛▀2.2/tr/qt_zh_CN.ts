<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>BomNum</name>
    <message>
        <location filename="../UI/BomNum.ui" line="14"/>
        <source>Select Bom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="20"/>
        <source>BOM Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="30"/>
        <source>BOM_00130</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="59"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/BomNum.ui" line="66"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoginDlg</name>
    <message>
        <location filename="../UI/Login.ui" line="33"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Login.ui" line="53"/>
        <source>Please input the password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Login.ui" line="75"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Login.ui" line="82"/>
        <source>CANCEL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../UI/mainwnd.ui" line="23"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="40"/>
        <source>Produce Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="46"/>
        <source>Basic+LuaDB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="53"/>
        <source>Only LuaDB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="60"/>
        <source>LuaDB_Bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="76"/>
        <source>Group Lua Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="83"/>
        <location filename="../UI/mainwnd.ui" line="103"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="88"/>
        <location filename="../UI/mainwnd.ui" line="108"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="93"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="98"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="122"/>
        <location filename="../UI/mainwnd.ui" line="397"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="128"/>
        <source>Append</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="135"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="142"/>
        <source>Select ALL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="174"/>
        <source>Select foundation platform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="180"/>
        <source>Basic File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="190"/>
        <location filename="../UI/mainwnd.ui" line="387"/>
        <source>B&amp;rowse&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="216"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="280"/>
        <location filename="../UI/mainwnd.ui" line="479"/>
        <source>Start all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="287"/>
        <location filename="../UI/mainwnd.ui" line="488"/>
        <source>Stop all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="313"/>
        <source>Initialize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="353"/>
        <source>Combine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="371"/>
        <source>Combined to generate files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="377"/>
        <source>Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="403"/>
        <source>Production </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="417"/>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="497"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="506"/>
        <source>User manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="294"/>
        <location filename="../UI/mainwnd.ui" line="515"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="524"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="539"/>
        <source>StatusBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="554"/>
        <source>ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/mainwnd.ui" line="563"/>
        <source>User management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="178"/>
        <source>Loading the lod file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="178"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="244"/>
        <source>&amp;Operations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="254"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="291"/>
        <source>Port number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="294"/>
        <source>Serial port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="297"/>
        <source>Progress (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="300"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="303"/>
        <source>Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <source>Port %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="151"/>
        <location filename="../mainwindow.cpp" line="429"/>
        <location filename="../mainwindow.cpp" line="870"/>
        <location filename="../mainwindow.cpp" line="879"/>
        <location filename="../mainwindow.cpp" line="2077"/>
        <location filename="../mainwindow.cpp" line="2191"/>
        <location filename="../mainwindow.cpp" line="3024"/>
        <location filename="../mainwindow.cpp" line="3031"/>
        <location filename="../mainwindow.cpp" line="3582"/>
        <location filename="../mainwindow.cpp" line="6270"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="129"/>
        <location filename="../mainwindow.cpp" line="3967"/>
        <source>8851 product download tool Vx.x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="133"/>
        <source>RDA download tool v8.00.09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>download.cfg did not exist,we will create a new file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <location filename="../mainwindow.cpp" line="899"/>
        <location filename="../mainwindow.cpp" line="1360"/>
        <location filename="../mainwindow.cpp" line="1367"/>
        <location filename="../mainwindow.cpp" line="2090"/>
        <location filename="../mainwindow.cpp" line="2204"/>
        <location filename="../mainwindow.cpp" line="2261"/>
        <location filename="../mainwindow.cpp" line="2275"/>
        <location filename="../mainwindow.cpp" line="2297"/>
        <location filename="../mainwindow.cpp" line="2311"/>
        <location filename="../mainwindow.cpp" line="2434"/>
        <location filename="../mainwindow.cpp" line="2470"/>
        <location filename="../mainwindow.cpp" line="2497"/>
        <location filename="../mainwindow.cpp" line="2505"/>
        <location filename="../mainwindow.cpp" line="2522"/>
        <location filename="../mainwindow.cpp" line="2530"/>
        <location filename="../mainwindow.cpp" line="2555"/>
        <location filename="../mainwindow.cpp" line="2569"/>
        <location filename="../mainwindow.cpp" line="2664"/>
        <location filename="../mainwindow.cpp" line="2672"/>
        <location filename="../mainwindow.cpp" line="2690"/>
        <location filename="../mainwindow.cpp" line="2698"/>
        <location filename="../mainwindow.cpp" line="2723"/>
        <location filename="../mainwindow.cpp" line="2737"/>
        <location filename="../mainwindow.cpp" line="2841"/>
        <location filename="../mainwindow.cpp" line="2910"/>
        <location filename="../mainwindow.cpp" line="3074"/>
        <location filename="../mainwindow.cpp" line="3088"/>
        <location filename="../mainwindow.cpp" line="3103"/>
        <location filename="../mainwindow.cpp" line="3143"/>
        <location filename="../mainwindow.cpp" line="3156"/>
        <location filename="../mainwindow.cpp" line="3446"/>
        <location filename="../mainwindow.cpp" line="3483"/>
        <location filename="../mainwindow.cpp" line="3561"/>
        <location filename="../mainwindow.cpp" line="3570"/>
        <location filename="../mainwindow.cpp" line="3611"/>
        <location filename="../mainwindow.cpp" line="3619"/>
        <location filename="../mainwindow.cpp" line="3627"/>
        <location filename="../mainwindow.cpp" line="3635"/>
        <location filename="../mainwindow.cpp" line="3643"/>
        <location filename="../mainwindow.cpp" line="3651"/>
        <location filename="../mainwindow.cpp" line="3861"/>
        <location filename="../mainwindow.cpp" line="5007"/>
        <location filename="../mainwindow.cpp" line="5014"/>
        <source>Error</source>
        <translation type="unfinished">错误</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="442"/>
        <location filename="../mainwindow.cpp" line="2090"/>
        <location filename="../mainwindow.cpp" line="2204"/>
        <source>Error configure file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="899"/>
        <source>Create configure error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1360"/>
        <location filename="../mainwindow.cpp" line="1367"/>
        <location filename="../mainwindow.cpp" line="5014"/>
        <source>Write Configure file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2077"/>
        <source>flashlist.cfg did not exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2261"/>
        <source>Import MBSN from excel file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2275"/>
        <source>Custom MBSN failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2297"/>
        <source>Import PSN from excel file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2311"/>
        <source>Custom PSN failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2434"/>
        <source>Can&apos;t update the History MBSN file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2470"/>
        <source>Can&apos;t update the History phone SN file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2497"/>
        <location filename="../mainwindow.cpp" line="2664"/>
        <source>The source file does not exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2505"/>
        <location filename="../mainwindow.cpp" line="2672"/>
        <source>Create a excel object failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2522"/>
        <location filename="../mainwindow.cpp" line="2690"/>
        <source>Not find the string sheet in the excel file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2530"/>
        <location filename="../mainwindow.cpp" line="2698"/>
        <source>Create a backup excel object failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2555"/>
        <location filename="../mainwindow.cpp" line="2723"/>
        <source>Empty file or the format of file is error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2569"/>
        <location filename="../mainwindow.cpp" line="2737"/>
        <source>Read excel file error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2841"/>
        <source>The custom part of MBSN must be digits or letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2910"/>
        <source>The custom part of PSN must be digits or letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4114"/>
        <source>Statu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4117"/>
        <source>Press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4120"/>
        <source>LuaFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4136"/>
        <source>No.%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5336"/>
        <location filename="../mainwindow.cpp" line="5344"/>
        <location filename="../mainwindow.cpp" line="5352"/>
        <location filename="../mainwindow.cpp" line="5402"/>
        <location filename="../mainwindow.cpp" line="5463"/>
        <location filename="../mainwindow.cpp" line="5469"/>
        <location filename="../mainwindow.cpp" line="5475"/>
        <location filename="../mainwindow.cpp" line="5482"/>
        <location filename="../mainwindow.cpp" line="5919"/>
        <location filename="../mainwindow.cpp" line="5926"/>
        <location filename="../mainwindow.cpp" line="6317"/>
        <location filename="../mainwindow.cpp" line="6332"/>
        <location filename="../mainwindow.cpp" line="6363"/>
        <source>warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5463"/>
        <source>Lod files illegal lack # $SCRIPT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5469"/>
        <source>Please select at least one lua files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5475"/>
        <source>main.lua not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5336"/>
        <source>error:Platform file can&apos;t Read </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5344"/>
        <source>error:Export file can&apos;t Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5352"/>
        <source>error: Temp_Download.lod can&apos;t Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6267"/>
        <source>[%1] has not been used, Continue to download?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6317"/>
        <source>LuaFile renaming failure!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6332"/>
        <source>Copy the Lua file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6363"/>
        <source>Script file compression failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5402"/>
        <source>ZipFile error:can&apos;t open  error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5482"/>
        <source>Failed to get scripts and user first address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5884"/>
        <source>Marge the Lod files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5888"/>
        <source>Combine the lod files failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5919"/>
        <source>error: Update failed to download the CFG file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5926"/>
        <source>error:LuaDB.bin are not allowed to download </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="151"/>
        <location filename="../mainwindow.cpp" line="3582"/>
        <source>Failed to get flash info from lod file, we will use the parameters in configure!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3102"/>
        <source>[%1] was not exist,please select the correct flash programmer file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2191"/>
        <source>lcdlist.cfg did not exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="127"/>
        <source>LuaDB tools and downloads_V1.4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3000"/>
        <source>About RDA download tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3001"/>
        <source>RDA download tool v8.00.09
Copyright reserved 2012-12-03</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3071"/>
        <source>Checksum of the lod file failed, Continue to download?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3128"/>
        <location filename="../mainwindow.cpp" line="3431"/>
        <location filename="../mainwindow.cpp" line="3468"/>
        <source>[%1] was not exist,please select the correct file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3132"/>
        <location filename="../mainwindow.cpp" line="3435"/>
        <location filename="../mainwindow.cpp" line="3472"/>
        <source>The address in cfp file must be equal to the calib address of current flash!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3136"/>
        <location filename="../mainwindow.cpp" line="3439"/>
        <location filename="../mainwindow.cpp" line="3476"/>
        <source>Can not find the calib section!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3140"/>
        <location filename="../mainwindow.cpp" line="3443"/>
        <location filename="../mainwindow.cpp" line="3480"/>
        <source>Open [%1] failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3155"/>
        <source>You must select at least one content to update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3560"/>
        <source>The program is already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3569"/>
        <source>Failed to Initiate the download file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3650"/>
        <source>You had not loaded a lod file successfully!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="870"/>
        <location filename="../mainwindow.cpp" line="879"/>
        <source>The length of the PSN was not equal to the length of the custum string!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3087"/>
        <location filename="../mainwindow.cpp" line="3626"/>
        <location filename="../mainwindow.cpp" line="3860"/>
        <source>Checksum of the lod file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3610"/>
        <source>Load ramrun file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3618"/>
        <source>Load Lod file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3634"/>
        <source>Load CFP file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3642"/>
        <source>Load erase file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="250"/>
        <source>&amp;Manage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDlg</name>
    <message>
        <location filename="../UI/Password.ui" line="13"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="53"/>
        <source>New password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="110"/>
        <source>Confirm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="137"/>
        <source>Old password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="169"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Password.ui" line="176"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDownloadThread</name>
    <message>
        <location filename="../DownloadThread.cpp" line="114"/>
        <location filename="../DownloadThread.cpp" line="159"/>
        <location filename="../DownloadThread.cpp" line="906"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="180"/>
        <source>Init uart port failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="193"/>
        <source>Open uart port failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="230"/>
        <source>Connecting Database...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="237"/>
        <source>Connect Database Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="249"/>
        <source>Idle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="320"/>
        <source>You had select a false flash type!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="335"/>
        <source>Downloading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="357"/>
        <source>Read Chip ID error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="367"/>
        <location filename="../DownloadThread.cpp" line="385"/>
        <location filename="../DownloadThread.cpp" line="406"/>
        <source>Base address was not matched!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="377"/>
        <location filename="../DownloadThread.cpp" line="416"/>
        <source>%1 file was not existed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="429"/>
        <source>Load ramrun failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="436"/>
        <source>Get UID failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="471"/>
        <location filename="../DownloadThread.cpp" line="674"/>
        <source>Read audio data from target failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="493"/>
        <location filename="../DownloadThread.cpp" line="696"/>
        <source>Read RF data from target failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="568"/>
        <source>Check the former worksite flag failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="613"/>
        <source>Get SN/IMEI Failed,please connect the DBM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="619"/>
        <source>IMEI number is invalid, please connect the DBM and check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="624"/>
        <source>BOM number of SN is invalid, please connect the DBM and check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="747"/>
        <source>Verify flash failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="752"/>
        <source>Calib RF CRC failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="757"/>
        <source>Magic number error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="762"/>
        <source>Fast programmer file failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="776"/>
        <source>Update Imei/SN status Failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="806"/>
        <source>Finished!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="297"/>
        <source>Lock the XCPU failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="274"/>
        <location filename="../DownloadThread.cpp" line="818"/>
        <source>Uart port was not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="342"/>
        <source>Enter host mode failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="515"/>
        <source>Read other data from target failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DownloadThread.cpp" line="718"/>
        <source>Read Other data from target failed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QLoginDlg</name>
    <message>
        <location filename="../Login.cpp" line="18"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Login.cpp" line="18"/>
        <source>The password is not correct!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="29"/>
        <location filename="../mainwindow.cpp" line="111"/>
        <location filename="../mainwindow.cpp" line="3358"/>
        <location filename="../mainwindow.cpp" line="3369"/>
        <location filename="../mainwindow.cpp" line="3396"/>
        <location filename="../mainwindow.cpp" line="3407"/>
        <location filename="../mainwindow.cpp" line="3512"/>
        <location filename="../mainwindow.cpp" line="3523"/>
        <source>Error</source>
        <translation type="unfinished">错误</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="111"/>
        <source>The flash you had selected was not existed in our flash list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="29"/>
        <source>You have already run an application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3358"/>
        <location filename="../mainwindow.cpp" line="3396"/>
        <location filename="../mainwindow.cpp" line="3512"/>
        <source>The lod file has overwrite the factorysetting sector!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3369"/>
        <location filename="../mainwindow.cpp" line="3407"/>
        <location filename="../mainwindow.cpp" line="3523"/>
        <source>The lod file has overwrite the calibration sector!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6161"/>
        <source>[%1] can&apos;t open for check!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="6230"/>
        <source>[%1] File does not exist the customer list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3184"/>
        <location filename="../mainwindow.cpp" line="3207"/>
        <location filename="../mainwindow.cpp" line="3234"/>
        <location filename="../mainwindow.cpp" line="3246"/>
        <location filename="../mainwindow.cpp" line="3273"/>
        <location filename="../mainwindow.cpp" line="3285"/>
        <location filename="../mainwindow.cpp" line="3313"/>
        <location filename="../mainwindow.cpp" line="3325"/>
        <location filename="../mainwindow.cpp" line="3346"/>
        <location filename="../mainwindow.cpp" line="3384"/>
        <location filename="../mainwindow.cpp" line="3500"/>
        <source>[%1] was not exist,please select the correct file!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPasswordDlg</name>
    <message>
        <location filename="../Password.cpp" line="18"/>
        <location filename="../Password.cpp" line="28"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Password.cpp" line="18"/>
        <source>The password is not correct!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Password.cpp" line="28"/>
        <source>The new password is not confirmed correctly!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSetupDialog</name>
    <message>
        <location filename="../SetupDialog.cpp" line="854"/>
        <location filename="../SetupDialog.cpp" line="1485"/>
        <location filename="../SetupDialog.cpp" line="1494"/>
        <location filename="../SetupDialog.cpp" line="1693"/>
        <location filename="../SetupDialog.cpp" line="1708"/>
        <location filename="../SetupDialog.cpp" line="1717"/>
        <location filename="../SetupDialog.cpp" line="1732"/>
        <location filename="../SetupDialog.cpp" line="1742"/>
        <location filename="../SetupDialog.cpp" line="1752"/>
        <location filename="../SetupDialog.cpp" line="1775"/>
        <location filename="../SetupDialog.cpp" line="1785"/>
        <location filename="../SetupDialog.cpp" line="1800"/>
        <location filename="../SetupDialog.cpp" line="1809"/>
        <location filename="../SetupDialog.cpp" line="1827"/>
        <location filename="../SetupDialog.cpp" line="1837"/>
        <location filename="../SetupDialog.cpp" line="1848"/>
        <location filename="../SetupDialog.cpp" line="1858"/>
        <location filename="../SetupDialog.cpp" line="1883"/>
        <location filename="../SetupDialog.cpp" line="1892"/>
        <location filename="../SetupDialog.cpp" line="1907"/>
        <location filename="../SetupDialog.cpp" line="1916"/>
        <location filename="../SetupDialog.cpp" line="1924"/>
        <location filename="../SetupDialog.cpp" line="1943"/>
        <location filename="../SetupDialog.cpp" line="1953"/>
        <location filename="../SetupDialog.cpp" line="1964"/>
        <location filename="../SetupDialog.cpp" line="1974"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1115"/>
        <location filename="../SetupDialog.cpp" line="1122"/>
        <source>The 1st worksite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1116"/>
        <location filename="../SetupDialog.cpp" line="1123"/>
        <source>The 2nd worksite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1117"/>
        <location filename="../SetupDialog.cpp" line="1124"/>
        <source>The 3rd worksite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1118"/>
        <location filename="../SetupDialog.cpp" line="1125"/>
        <source>The 4th worksite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1119"/>
        <location filename="../SetupDialog.cpp" line="1126"/>
        <source>The 5th worksite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1120"/>
        <location filename="../SetupDialog.cpp" line="1127"/>
        <source>The 6th worksite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1129"/>
        <source>Normal mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1130"/>
        <source>Auto dial mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1131"/>
        <source>Auto reply mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1132"/>
        <source>Auto test mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1234"/>
        <source>Port number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1237"/>
        <source>Serial port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1240"/>
        <source>Baud rate(bps)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1250"/>
        <source>Port 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1267"/>
        <source>Port 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1284"/>
        <source>Port 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1301"/>
        <source>Port 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1318"/>
        <source>Port 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1494"/>
        <source>The length of Init or Mask code of PSN error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1799"/>
        <source>MBSN&apos;s initial number must be digits or letters and consist of %1 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1906"/>
        <source>PSN&apos;s initial number must be digits or letters and consist of %1 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1693"/>
        <source>Serial Port can not repeat.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1708"/>
        <source>Program file can not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1717"/>
        <source>Accessional file can not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1732"/>
        <source>Check last worksite flag can not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1742"/>
        <source>Set current worksite flag can not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1752"/>
        <source>Set check flag can not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1775"/>
        <source>MBSN&apos;s max limited number must be digits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1785"/>
        <source>MBSN&apos;s max limited number can&apos;t exceed 100000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1809"/>
        <location filename="../SetupDialog.cpp" line="1827"/>
        <source>MBSN&apos;s mask is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1837"/>
        <location filename="../SetupDialog.cpp" line="1858"/>
        <source>MBSN&apos;s initial number and Mask should match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1848"/>
        <source>MBSN&apos;s custom-made characters must be digitals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1883"/>
        <source>PSN&apos;s max limited number must be digits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1892"/>
        <source>PSN&apos;s max limited number can&apos;t exceed 100000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1916"/>
        <location filename="../SetupDialog.cpp" line="1924"/>
        <location filename="../SetupDialog.cpp" line="1943"/>
        <source>PSN&apos;s mask is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1953"/>
        <location filename="../SetupDialog.cpp" line="1974"/>
        <source>PSN&apos;s initial number and Mask should match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1964"/>
        <source>PSN&apos;s custom-made characters must be digitals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="520"/>
        <location filename="../SetupDialog.cpp" line="526"/>
        <location filename="../SetupDialog.cpp" line="534"/>
        <location filename="../SetupDialog.cpp" line="540"/>
        <location filename="../SetupDialog.cpp" line="549"/>
        <location filename="../SetupDialog.cpp" line="559"/>
        <location filename="../SetupDialog.cpp" line="574"/>
        <source>Error</source>
        <translation type="unfinished">错误</translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="520"/>
        <source>Lod file must not be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="526"/>
        <location filename="../SetupDialog.cpp" line="540"/>
        <source>[%1] is not exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="534"/>
        <source>Update file must not be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="574"/>
        <source>You must select a LCD ID!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="854"/>
        <source>Failed to get flash info from lod file,you must set the flash parameters manual!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="549"/>
        <location filename="../SetupDialog.cpp" line="559"/>
        <source>You must select at least on content to be updated!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SetupDialog.cpp" line="1485"/>
        <source>The length of Init or Mask code of MBSN error!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <location filename="../UI/setupdlg.ui" line="14"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="73"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="97"/>
        <source>Port setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="163"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="181"/>
        <source>Download files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="369"/>
        <source>Accessional file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="272"/>
        <location filename="../UI/setupdlg.ui" line="398"/>
        <location filename="../UI/setupdlg.ui" line="957"/>
        <location filename="../UI/setupdlg.ui" line="1119"/>
        <source>Browse&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="281"/>
        <location filename="../UI/setupdlg.ui" line="431"/>
        <source>Update calibration paramters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="293"/>
        <location filename="../UI/setupdlg.ui" line="443"/>
        <source>Audio data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="303"/>
        <location filename="../UI/setupdlg.ui" line="453"/>
        <source>RF data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="235"/>
        <source>Program file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="487"/>
        <source>LCD Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="509"/>
        <source>LCD Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="571"/>
        <location filename="../UI/setupdlg.ui" line="597"/>
        <source>Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="617"/>
        <source>Flash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="667"/>
        <source>Erase setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="679"/>
        <source>Erase user date sector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="692"/>
        <source>Erase factory setting sector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="702"/>
        <source>Erase calibration sector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="709"/>
        <source>Erase full flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="735"/>
        <source>Set flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="777"/>
        <source>Flag options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="803"/>
        <source>Check last worksite flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="816"/>
        <source>Set current worksite flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="829"/>
        <source>Set power on mode flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="906"/>
        <source>Write SN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="921"/>
        <source>Motherboard SN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="947"/>
        <location filename="../UI/setupdlg.ui" line="1102"/>
        <source>From data file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="974"/>
        <location filename="../UI/setupdlg.ui" line="1136"/>
        <source>Custom number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1020"/>
        <location filename="../UI/setupdlg.ui" line="1188"/>
        <source>Initial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1034"/>
        <location filename="../UI/setupdlg.ui" line="1205"/>
        <source>Mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1058"/>
        <location filename="../UI/setupdlg.ui" line="1232"/>
        <source>Max limited number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1076"/>
        <source>Phone SN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1248"/>
        <location filename="../UI/setupdlg.ui" line="1260"/>
        <location filename="../UI/setupdlg.ui" line="1285"/>
        <source>DataBase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1275"/>
        <source>Data Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1299"/>
        <source>User Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1313"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1348"/>
        <source>Sequence No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1358"/>
        <source>Prdt Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="1374"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="47"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="54"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="323"/>
        <location filename="../UI/setupdlg.ui" line="473"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/setupdlg.ui" line="313"/>
        <location filename="../UI/setupdlg.ui" line="463"/>
        <source>GPADC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
